//package Registration;
//
//import java.io.IOException;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//
//import javax.servlet.RequestDispatcher;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;
//
///**
// * Servlet implementation class login
// */
//@WebServlet("/login")
//public class login extends HttpServlet {
//	private static final long serialVersionUID = 1L;
//       
//    /**
//     * @see HttpServlet#HttpServlet()
//     */
//    public login() {
//        super();
//        // TODO Auto-generated constructor stub
//    }
//
//
//	
//	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		String u=request.getParameter("username");
//		String p=request.getParameter("passwod");
//		HttpSession session=request.getSession();
//		RequestDispatcher dispatcher=null;
//		try{
//	          Class.forName("com.mysql.cj.jdbc.Driver");// LOAD A JDBC DRIVER
//	          Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/user?characterEncoding=utf8&useUnicode=true","root","Shimbu@123456");
//	          PreparedStatement ps=con.prepareStatement("select *from user where username=? and password=?");
//	          ps.setString(1, u);
//	          ps.setString(2, p);
//	         ResultSet rs= ps.executeQuery();
//	         if(rs.next())
//	         {
//	        	 session.setAttribute("username",rs.getString(u));
//	        	 dispatcher=request.getRequestDispatcher("index.jsp");
//	        	 
//	         }else
//	         {
//	        	 request.setAttribute("status","failed");
//	        	 dispatcher= request.getRequestDispatcher("login.jsp");
//	    
//	         }
//	         
//	        	 dispatcher.forward(request, response);
//	         
////	          //ESTABLISHED A CONNECTION
////	          System.out.println("Got the connection");
////	          System.out.println("connection="+con);
////	          System.out.println("Database connected  successfully");
////	          // PERFORM A TASK
//	       }catch(Exception e)
//	       {
//	          System.err.println(e);
//	       }
//		
//	}
//
//}



package Registration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public login() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String u = request.getParameter("username");
		String p = request.getParameter("password"); // fixed typo
		HttpSession session = request.getSession();
		RequestDispatcher dispatcher = null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/user?characterEncoding=utf8&useUnicode=true", 
				"root", 
				"Shimbu@123456"
			);
			
			PreparedStatement ps = con.prepareStatement("SELECT * FROM user WHERE username = ? AND password = ?");
			ps.setString(1, u);
			ps.setString(2, p);
			
			ResultSet rs = ps.executeQuery();
			
			if (rs.next()) {
				session.setAttribute("username", rs.getString("username")); // fixed
				dispatcher = request.getRequestDispatcher("index.jsp");
			} else {
				request.setAttribute("status", "failed");
				dispatcher = request.getRequestDispatcher("login.jsp");
			}

			dispatcher.forward(request, response);

			rs.close();
			ps.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace(); // more helpful than just printing to stderr
		}
	}
}
